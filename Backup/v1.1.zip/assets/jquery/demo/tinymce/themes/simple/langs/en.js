tinyMCE.addI18n('en.simple',{
bold_desc:"Bold (Ctrl+B)",
italic_desc:"Italic (Ctrl+I)",
underline_desc:"Underline (Ctrl+U)",
striketrough_desc:"Strikethrough",
bullist_desc:"Unordered list",
numlist_desc:"Ordered list",
undo_desc:"Undo (Ctrl+Z)",
redo_desc:"Redo (Ctrl+Y)",
cleanup_desc:"Cleanup messy code"
});