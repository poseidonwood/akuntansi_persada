  
	<div class="row">
  		<div class="col-md-12">
		  <footer class="main-footer  text-center">
		    Copyright ©2019 <a target="blank" href="http://rumahit.id" > Designed & development by: Rumah IT</a> 
		  </footer> 
  		</div>
  </div>
</div>
<!-- Added New JS -->
<!-- Metis Menu Plugin JavaScript -->

<script src="<?php echo base_url(); ?>assets/front_menu/js/sidebar-menu.js"></script>
<script>
	$.sidebarMenu($('.sidebar-menu'))
</script>